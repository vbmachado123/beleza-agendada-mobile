import 'package:beleza_agendada/models/customer.dart';
import 'package:beleza_agendada/service/api.dart' as api;

class customerController {
  customerController();

  add(Customer customer) async {}

  update(Customer customer) async {}

  delete(Customer customer) async {}
}

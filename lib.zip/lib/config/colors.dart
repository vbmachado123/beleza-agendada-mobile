

const clienteColor = "#D95E63";
const profissionalColor = "#9247D9";
const salaoColor = "#336699";